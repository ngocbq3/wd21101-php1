<?php

class AdminProductController
{
    //hiển thị danh sách sản phẩm
    public function index()
    {
        $products = (new Product)->all();

        include_once "Views/admin/products/list.php";
    }

    //Hiển thị form thêm mới
    public function create()
    {
        //lấy ra danh mục
        $categories = (new Category)->all();
        include_once "Views/admin/products/add.php";
    }

    //Thêm dữ liệu vào database
    public function store()
    {
        //lấy dữ liệu từ form
        $data = $_POST;

        //Thêm image rống
        $data['image'] = '';

        //Thêm vào
        (new Product)->create($data);
        header("location:" . BASE_URL . '?c=admin-product');
        die;
    }
}
