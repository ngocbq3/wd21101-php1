<?php

const BASE_URL = "http://localhost/wd21101_php1/mvc/";
